from dataclasses import dataclass, field
from zipfile import ZipFile
from xml.etree import ElementTree as ET
import re

from bs4 import BeautifulSoup

DOC_RANGES = [(1,17),(18,53),(54,99),(100,155),(156,199),(250,301),(302,395),(200,249)]
DOC_NAMES = [
    f"pregnancy-lactation-safety-{part}{start:02d}-{end}.docx"
    for (start,end),part in zip(DOC_RANGES, ("","drugs-","","drugs-","drugs-","drugs-","",""),strict=True)
]
HTML_NAME = "Pregnancy_Lactation_250_Combined_Offline.html"
W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def paragraph_text(element):
    return "".join(t.text or "" for t in element.iter(W+"t"))


def cell_text(element):
    return "\n".join(paragraph_text(p) for p in element.findall(W+"p"))


@dataclass
class Group:
    source: str
    title: str
    class_name: str
    headers: list = field(default_factory=list)
    rows: list = field(default_factory=list)
    context: list = field(default_factory=list)
    bibliography: object = None


def word_sources(source_dir):
    for (start,end),name in zip(DOC_RANGES,DOC_NAMES):
        with ZipFile(source_dir/name) as archive:
            body = ET.fromstring(archive.read("word/document.xml")).find(W+"body")
        assert {node.tag for node in body} <= {W+t for t in ("p","tbl","sectPr")}
        assert not any(node.tag in {W+t for t in ("drawing","object","footnoteReference","endnoteReference","sdt","ins","del","numPr","gridSpan","vMerge","br","tab","hyperlink","vertAlign")} for node in body.iter())
        title = paragraph_text(body[0])
        notes,groups,sequence,side_tables = [],[],[],[]
        current = None
        for node in list(body)[1:]:
            if node.tag == W+"p":
                value = paragraph_text(node)
                if not value.strip():
                    continue
                heading = re.fullmatch(r"\d{1,2}\.\s+(.+)",value)
                if heading:
                    current = Group(name,value,heading[1])
                    groups.append(current)
                elif value in {"Summary Count","Quick Summary"}:
                    current = None
                    notes.append(value)
                elif current is not None and not value.startswith(("Disclaimer:","This chart is","Contraindicated / clearly avoid (summary):","Safe-choice alternatives:","Summary – ","Preferred substitutes:")):
                    current.context.append(value)
                else:
                    notes.append(value)
            elif node.tag == W+"tbl":
                table = [[cell_text(td) for td in tr.findall(W+"tc")] for tr in node.findall(W+"tr")]
                if table[0][0] == "#":
                    assert current is not None and not current.rows,(name,current)
                    current.headers,current.rows = table[0],table[1:]
                    for row in current.rows:
                        match = re.fullmatch(r"(\d+)(?:[–-](\d+))?",row[0])
                        assert match and len(row)==len(current.headers),(name,row)
                        sequence.extend(range(int(match[1]),int(match[2] or match[1])+1))
                else:
                    side_tables.append(table)
        assert sequence == list(range(start,end+1)),(name,sequence)
        assert all(group.rows for group in groups),(name,groups)
        yield name,title,notes,groups,side_tables


def html_source(source_dir):
    soup = BeautifulSoup((source_dir/HTML_NAME).read_text(encoding="utf-8"),"html.parser")
    notes,groups = [],[]
    group = None
    for node in soup.body.find_all(recursive=False):
        if node.name == "h2":
            heading = re.fullmatch(r"\d{2}\. (.+)",node.get_text())
            if heading:
                group = Group(HTML_NAME,node.get_text(),heading[1])
                groups.append(group)
        elif group is None:
            if node.name == "p":
                notes.append(node)
        elif node.name == "table":
            group.headers = [cell.get_text() for cell in node.select("thead th")]
            group.rows = [tr.find_all("td",recursive=False) for tr in node.select("tbody tr")]
            assert group.headers == ["Therapeutic Class","Drug","Pregnancy","Lactation"]
            assert all(len(r)==4 for r in group.rows)
        elif node.name == "ol":
            group.bibliography = node
        elif node.name not in {"hr","h3"}:
            group.context.append(node)
    assert len(groups)==11 and sum(len(g.rows) for g in groups)==212
    assert all(g.bibliography is not None and g.context for g in groups)
    return soup.h1.get_text(),notes,groups
