import re
from html import escape


STATUS_LABELS = {
    "safe": "✅ SAFE",
    "caution": "⚠️ CAUTION",
    "avoid": "❌ AVOID / UNSAFE",
}

WORDING = {
    "safe": (
        "Safe", "Acceptable", "Compatible", "First-line", "Preferred",
    ),
    "caution": (
        "Caution", "Probably compatible", "Likely safe", "Probably acceptable",
        "Low risk", "Moderate risk", "Use when indicated", "Use if benefit justifies risk",
        "Second-line", "Prefer an alternative", "T2/T3 only", "Fetal indications only",
        "Use with infant monitoring", "Occasional or short-term use only",
        "Limited data", "No human data", "Disputed", "Class limits",
        "Use with caution", "Use only", "Use if", "Use when", "Only if",
        "Prefer another", "Prefer alternatives", "Acceptable with caution",
    ),
    "avoid": (
        "Avoid", "Unsafe", "Contraindicated", "Not recommended", "Do not breastfeed",
        "Not indicated", "Label advises against", "Do not use", "Oral PUVA contraindicated",
    ),
}

MIXED_EXAMPLES = (
    "Avoid (oral/systemic) · ✅ topical",
    "AVOID in 1st trimester; CAUTION after",
    "SAFE (ACR) / label advises against",
)
def pattern(phrases):
    alternatives = [re.escape(phrase).replace(r"\-",r"[-\s]").replace(r"\ ",r"\s+") for phrase in phrases]
    return re.compile(r"^(?:"+"|".join(alternatives)+r")\b",re.I)


PREFIXES = {grade:pattern(phrases) for grade,phrases in WORDING.items()}
CLAUSE = re.compile(r"\s*(?:,?\s+but\s+|[,;·]|\s/\s)\s*",re.I)
LABEL_AGAINST = re.compile(r"(?:^|[;/·]|\bbut)\s*(?:the\s+)?label advises against\b",re.I)
LABEL_PREFIX = re.compile(r"^label\s*:\s*",re.I)


def source_status(assessment):
    value = assessment.strip()
    lead = LABEL_PREFIX.sub("",value.lstrip("✅⚠❌\ufe0f "))
    if LABEL_AGAINST.search(lead) or PREFIXES["avoid"].match(lead) or value.startswith("❌"):
        return "avoid"
    if PREFIXES["caution"].match(lead) or value.startswith("⚠"):
        return "caution"
    later_clauses = CLAUSE.split(lead)[1:]
    if any(clause.startswith("❌") or PREFIXES["avoid"].match(clause) for clause in later_clauses):
        return "avoid"
    if any(clause.startswith("⚠") or PREFIXES["caution"].match(clause) for clause in later_clauses):
        return "caution"
    if PREFIXES["safe"].match(lead) or value.startswith("✅"):
        return "safe"
    return ""


def safety_legend():
    items = "".join(
        f'<li data-safety="{grade}"><strong>{STATUS_LABELS[grade]}</strong>'
        f'<span>{escape(", ".join(WORDING[grade]))}</span></li>'
        for grade in STATUS_LABELS
    )
    examples = "".join(f'<li>{escape(value)}</li>' for value in MIXED_EXAMPLES)
    return (
        '<template id="guideSafetyLegend"><p>Wording that triggers each badge</p>'
        f'<ul class="guide-safety-legend">{items}</ul>'
        '<h3 class="guide-safety-rules-heading">When more than one rule matches</h3>'
        '<p>A leading CAUTION is yellow, including when it gives a restriction. '
        'A leading AVOID, CONTRAINDICATED or other red rule stays red. '
        '“Label advises against” also takes priority. Caution phrases such as '
        '“Probably compatible” and “Likely safe” take priority over green wording. '
        'A later explicit red or caution clause can override a green opening.</p>'
        f'<p>Examples that display a red badge</p><ul class="guide-safety-examples">{examples}</ul>'
        '<p>Matching is case-insensitive. An opening “Label:” is skipped when matching the wording that follows. '
        'The badge uses the DOCX rating or the original HTML’s '
        'opening assessment. An existing leading ✅, ⚠️ or ❌ also helps identify the category. '
        'Source wording remains visible below the badge. Cells without a matching rule have no badge. '
        'Read the source wording for route, timing, conditions and differences between sources.</p></template>'
    )
