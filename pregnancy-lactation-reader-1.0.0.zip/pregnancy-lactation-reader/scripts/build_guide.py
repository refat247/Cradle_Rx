import argparse
from collections import defaultdict, Counter
from dataclasses import dataclass
from hashlib import sha256
from html import escape
from pathlib import Path
import json
import re

from bs4 import BeautifulSoup, NavigableString

from classes import HTML_CLASSES, WORD_NAMES, WORD_ROW_CLASSES
from reader_successor import update_reader
from safety_legend import STATUS_LABELS, source_status
from source_data import DOC_NAMES, HTML_NAME, word_sources, html_source

SKILL = Path(__file__).resolve().parent.parent
TEMPLATE = SKILL/"assets/reader-v6_1.html"
BASELINE = SKILL/"references/baseline.json"
TITLE = "Pregnancy and Lactation Drug Reference"
BOOK_ID = "pregnancy-lactation-therapeutic-classes"
STABLE_SEMVER = re.compile(r"(?:0|[1-9][0-9]*)(?:\.(?:0|[1-9][0-9]*)){2}")
HEADERS = ["Drug / product", "Pregnancy", "Lactation", "Key notes"]
INLINE = {"strong","em","small","code","b","i","sup","sub"}
SOURCE_TAGS = INLINE | {"p","ul","ol","li","blockquote","a","br"}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def html_source_node(node, inline=False):
    if isinstance(node,NavigableString):
        return escape(str(node))
    assert node.name in (INLINE if inline else SOURCE_TAGS), node.name
    body = "".join(html_source_node(child,inline) for child in node.children)
    if node.name == "a":
        href = node.get("href","")
        if href.startswith(("https://","http://")):
            return f'<a href="{escape(href,quote=True)}">{body}</a>'
        return body
    if node.name == "br":
        return "<br>"
    return f"<{node.name}>{body}</{node.name}>"


def para(value):
    return "<p>" + escape(value) + "</p>"


def plain(html):
    return BeautifulSoup(html,"html.parser").get_text()


def word_cell(value):
    return "<span class=\"source-text\">"+escape(value)+"</span>"


def fold(identifier,title,content,kind="source-detail-fold"):
    return f'<details class="fold {kind}" id="{identifier}"><summary>{escape(title)}</summary><div class="fold-body">{content}</div></details>'


def slug(label):
    return re.sub(r"[^a-z0-9]+","-",label.casefold()).strip("-")


def sort_key(text):
    return re.sub(r"[\W_]+"," ",text.casefold()).strip()


@dataclass
class Row:
    id: str
    name: str
    cells: list
    source_label: str
    locator: str
    target: str
    original_cells: list
    references: str = ""


def article(identifier,title,body):
    return f'<article class="chapter" id="{identifier}"><h2 class="chapter-title">{escape(title)}</h2>{body}</article>'


def table(headings,body,classes=""):
    heads = "".join(f'<th scope="col">{escape(h)}</th>' for h in headings)
    return f'<div class="table-wrapper {classes}"><table><thead><tr>{heads}</tr></thead><tbody>{body}</tbody></table></div>'


def assessment(row,index):
    if row.id.startswith("docx-"):
        column = {1:2,2:4 if len(row.original_cells)==6 else 3}
        return row.original_cells[column[index]]
    source = BeautifulSoup(row.cells[index],"html.parser")
    first = next((n for n in source.contents if str(n).strip()),None)
    return first.get_text() if getattr(first,"name",None) in {"strong","b","em"} else source.get_text()


def make_row(row):
    locator = escape(row.locator)
    refs = (" · "+escape(row.references)) if row.references else ""
    source = (
        f'<details class="fold reference-fold row-source" id="{row.id}-source">'
        f'<summary>{escape(row.source_label)}{refs}</summary>'
        f'<div class="reference-entry"><strong>{escape(row.source_label)}</strong><span> · {locator}</span>'
        f'<a class="source-jump" href="#{row.target}">Open source details</a></div></details>'
    )
    result = []
    for i,(label,content) in enumerate(zip(HEADERS,row.cells)):
        if i==3 and not content:
            result.append(f'<td class="empty-note" id="{row.id}-cell-{i+1}" data-label="{label}"></td>')
        else:
            grade = source_status(assessment(row,i)) if i in (1,2) else ""
            safety = f' data-safety="{grade}"' if grade else ""
            badge = f'<span class="safety-badge">{STATUS_LABELS[grade]}</span>' if grade else ""
            result.append(f'<td id="{row.id}-cell-{i+1}" data-label="{label}"{safety}>{badge}<div class="source-value">{content}</div>{source if i==0 else ""}</td>')
    return f'<tr id="{row.id}">'+"".join(result)+"</tr>"


def add_ids(soup):
    counters = Counter()
    for chapter in soup.select("article.chapter"):
        for item in chapter.select("h2,h3,h4,p,li,th,td,.reference-entry"):
            if item.has_attr("id"):
                continue
            detail = item.find_parent("details",id=True)
            owner = detail["id"] if detail else chapter["id"]
            key = f"{owner}-{item.name}"
            counters[key] += 1
            item["id"] = f"{key}-{counters[key]}"


def assemble(source_dir):
    groups_by_class = defaultdict(list)
    source_articles = []
    source_counts = Counter()
    source_evidence = {}
    for i,(name,title,notes,groups,side_tables) in enumerate(word_sources(source_dir),1):
        sid = f"word-{i}"
        source_label = "DOCX "+re.search(r"\d+-\d+",name)[0]
        context = para(name)+"".join(para(note) for note in notes)
        source_evidence[name] = {"id":sid,"notes":notes,"side_tables":side_tables,"context":{}}
        for values in side_tables:
            rows = "".join("<tr>"+"".join(f"<td>{word_cell(v)}</td>" for v in r)+"</tr>" for r in values[1:])
            context += table(values[0],rows)
        for g in groups:
            cls = WORD_NAMES.get(g.class_name,g.class_name)
            for original in g.rows:
                ref,drug,preg,*remaining = original
                rid = "docx-drug-"+ref.replace("–","-")
                if len(remaining)==3:
                    preg_note,lact,lact_note = remaining
                    columns = [word_cell(drug),word_cell(preg)+f'<div class="source-notes">{word_cell(preg_note)}</div>',word_cell(lact)+f'<div class="source-notes">{word_cell(lact_note)}</div>',""]
                else:
                    lact,note = remaining
                    columns = [word_cell(drug),word_cell(preg),word_cell(lact),word_cell(note)]
                locator = g.title + " · source entry "+ref
                display_class = WORD_ROW_CLASSES.get(ref,cls)
                groups_by_class[display_class].append(Row(rid,drug,columns,source_label,locator,sid,original))
                source_counts[name]+=1
            if g.context:
                identifier = sid+"-context-"+slug(g.class_name)
                context += fold(identifier,g.class_name+" — source notes","".join(para(p) for p in g.context))
                source_evidence[name]["context"][identifier] = g.context
        source_articles.append(article(sid,title,context))

    title,notes,groups = html_source(source_dir)
    source_articles.append(article("oe-overview",title,para(HTML_NAME)+fold("oe-original-overview","Original HTML overview","".join(html_source_node(node) for node in notes))))
    source_evidence[HTML_NAME] = {"overview":[n.get_text() for n in notes],"sections":[]}
    for section,(g,spans) in enumerate(zip(groups,HTML_CLASSES,strict=True),1):
        sid = f"oe-section-{section:02d}"
        source_label = f"OpenEvidence · {section:02d}"
        assert [i for start,end,_ in spans for i in range(start,end+1)]==list(range(1,len(g.rows)+1))
        for start,end,cls in spans:
            for i in range(start,end+1):
                category,drug,preg,lact = g.rows[i-1]
                clean = BeautifulSoup(drug.decode_contents(),"html.parser")
                refs = ""
                for t in list(clean.find_all(string=True)):
                    match = re.fullmatch(r"(.*?)<small>(.*?)</small>(.*)",str(t),flags=re.S)
                    if match:
                        assert not refs
                        refs = match[2].strip()
                        t.replace_with(match[1]+match[3])
                drug_html = "".join(html_source_node(n,True) for n in clean.contents).strip()
                values = [drug_html,"".join(html_source_node(n,True) for n in preg.contents),"".join(html_source_node(n,True) for n in lact.contents),""]
                rid = f"oe-{section:02d}-row-{i:02d}"
                locator = f"{g.title} · {category.get_text(strip=True)} · table row {i}"
                groups_by_class[cls].append(Row(rid,plain(drug_html).strip(),values,source_label,locator,sid+"-references",[t.get_text() for t in (category,drug,preg,lact)],refs))
                source_counts[HTML_NAME]+=1
        refs = fold(sid+"-references","References from the original section",html_source_node(g.bibliography),"reference-fold")
        notes_fold = fold(sid+"-original-notes","Original OpenEvidence explanations and notes","".join(html_source_node(node) for node in g.context))
        source_articles.append(article(sid,g.class_name,para(HTML_NAME)+refs+notes_fold))
        source_evidence[HTML_NAME]["sections"].append({"id":sid,"references":[n.get_text() for n in g.bibliography.find_all("li",recursive=False)],"notes":[n.get_text() for n in g.context]})

    class_html = []
    for cls,rows in sorted(groups_by_class.items(),key=lambda item:sort_key(item[0])):
        rows.sort(key=lambda row:sort_key(row.name))
        if any(row.cells[-1] for row in rows):
            heads = HEADERS
        else:
            heads = HEADERS[:3]
        rows_html = "".join(make_row(row) for row in rows)
        if len(heads)==3:
            rows_html = re.sub(r'<td class="empty-note"[^>]*></td>',"",rows_html)
        class_html.append(article("class-"+slug(cls),cls,table(heads,rows_html,"drug-table")))

    info = f"""
<h1>{TITLE}</h1>
<p>Therapeutic classes and drug names in alphabetical order.</p>
<div class="reading-options"><button id="toggleReferences" type="button" aria-expanded="false">Show all references</button></div>
<section class="doc-section" id="reader-overview"><h2 class="section-title">Overview</h2>
{article("start-here","About this reference",para("This offline compilation reproduces the supplied drug assessments for study. Clinical accuracy and the cited publications were not independently verified.")+para("Source records remain separate where a drug occurs more than once. Grouped products remain together. Open a row’s source label to see its original section and references.")+para("The eight DOCX files cover entries 1–395 in 387 rows. Four rows contain grouped entries. The original OpenEvidence HTML supplies 212 additional source rows."))}
</section>
<section class="doc-section" id="therapeutic-classes"><h2 class="section-title">Therapeutic Classes</h2>
{"".join(class_html)}</section>
<section class="doc-section" id="source-register"><h2 class="section-title">Sources and Original Notes</h2>
{"".join(source_articles)}</section>
"""
    soup = BeautifulSoup(info,"html.parser")
    add_ids(soup)
    return str(soup),groups_by_class,source_counts,source_evidence


def validate(output,groups,counts,evidence,previous):
    html = BeautifulSoup(output,"html.parser")
    expected = sorted(groups,key=sort_key)
    chapters = html.select("#therapeutic-classes > article")
    assert [c.h2.get_text() for c in chapters]==expected
    ids = [n["id"] for n in html.select("[id]")]
    by_id = {n["id"]:n for n in html.select("[id]")}
    assert len(ids)==len(set(ids))
    assert not html.select("details[open],script[src],link[rel=stylesheet],iframe,img[src],.bengali-fold")
    for cls,chapter in zip(expected,chapters):
        actual_rows = chapter.select("tbody tr")
        assert [r["id"] for r in actual_rows]==[row.id for row in groups[cls]]
        for rendered,row in zip(actual_rows,groups[cls]):
            assert [cell.get_text() for cell in rendered.select(".source-value")]==[plain(cell) for cell in row.cells if cell]
            assert rendered.select_one(".source-jump")["href"]=="#"+row.target and row.target in by_id
            if row.id.startswith("oe-"):
                assert plain(row.cells[1])==row.original_cells[2] and plain(row.cells[2])==row.original_cells[3]
                drug = re.sub(r"<small>.*?</small>","",row.original_cells[1]).strip()
                assert drug==row.name
                refs = re.findall(r"<small>(.*?)</small>",row.original_cells[1])
                assert row.references==(" ".join(refs).strip())
            else:
                ref,drug,preg,*tail = row.original_cells
                actual = rendered.select(".source-value")
                assert actual[0].get_text()==drug
                assert actual[1].select_one(".source-text").get_text()==preg
                if len(tail)==3:
                    assert actual[1].select_one(".source-notes").get_text()==tail[0]
                    assert actual[2].select_one(".source-text").get_text()==tail[1]
                    assert actual[2].select_one(".source-notes").get_text()==tail[2]
                else:
                    assert [v.get_text() for v in actual[2:]]==tail
    for s in evidence[HTML_NAME]["sections"]:
        actual = [v.get_text() for v in html.select(f'#{s["id"]}-references > .fold-body > ol > li')]
        assert actual==s["references"], (s["id"],len(actual),len(s["references"]),next(((a,b) for a,b in zip(actual,s["references"]) if a!=b),None))
        actual = [v.get_text() for v in html.select(f'#{s["id"]}-original-notes > .fold-body > *')]
        assert actual==s["notes"], (s["id"],len(actual),len(s["notes"]),next(((a,b) for a,b in zip(actual,s["notes"]) if a!=b),None))
    assert [v.get_text() for v in html.select("#oe-original-overview .fold-body > p")]==evidence[HTML_NAME]["overview"]
    for name in DOC_NAMES:
        source = evidence[name]
        selector = "#"+source["id"]
        assert [p.get_text() for p in html.select(selector+" > p")]==[name,*source["notes"]]
        for identifier,notes in source["context"].items():
            assert [p.get_text() for p in html.select("#"+identifier+" .fold-body > p")]==notes
        actual_tables = [
            [[cell.get_text() for cell in row.find_all(["th","td"],recursive=False)] for row in tbl.select("tr")]
            for tbl in html.select(selector+" > .table-wrapper > table")
        ]
        assert actual_tables==source["side_tables"]
    assert counts["pregnancy-lactation-safety-200-249.docx"]==50
    assert sum(counts.values())==599,counts
    grades = Counter()
    for cell in html.select('.drug-table td[data-label="Pregnancy"],.drug-table td[data-label="Lactation"]'):
        grade = cell.get("data-safety","")
        badge = cell.select_one(":scope > .safety-badge")
        assert bool(badge)==bool(grade)
        grades[grade or "unmatched"] += 1
        if grade:
            assert badge.get_text()==STATUS_LABELS[grade]
    if previous is not None:
        previous_ids = {node["id"] for node in previous.select("#therapeutic-classes [id],#source-register [id]")}
        assert previous_ids.issubset(ids)
        for row in previous.select("#therapeutic-classes tbody tr"):
            current = by_id[row["id"]]
            assert current.select(".source-value")==row.select(".source-value"),row["id"]
            assert current.select_one(".row-source")==row.select_one(".row-source"),row["id"]
        for node in previous.select("#source-register article"):
            assert by_id[node["id"]]==node,node["id"]
    assert sum(grades.values())==1198
    return grades


def main():
    if not __debug__:
        raise SystemExit("Run without -O or PYTHONOPTIMIZE. Content checks require assertions.")
    parser = argparse.ArgumentParser(description="Rebuild the locked Pregnancy and Lactation Reader source set")
    parser.add_argument("--sources",required=True,type=Path,help="Directory holding the nine original inputs")
    parser.add_argument("--out-dir",required=True,type=Path,help="A new directory for the HTML and build manifest")
    parser.add_argument("--version",help="Stable reader SemVer. Defaults to the frozen reader baseline.")
    parser.add_argument("--previous",type=Path,help="Earlier reader HTML. Required for a successor.")
    args = parser.parse_args()
    frozen = json.loads(BASELINE.read_text(encoding="utf-8"))
    version = args.version or frozen["version"]
    if not STABLE_SEMVER.fullmatch(version):
        parser.error("--version must be a stable MAJOR.MINOR.PATCH")
    if args.out_dir.exists():
        parser.error("--out-dir already exists")
    if version != frozen["version"] and args.previous is None:
        parser.error("--previous is required for a successor")
    previous = None
    previous_hash = None
    if args.previous is not None:
        previous_hash = digest(args.previous)
        previous = BeautifulSoup(args.previous.read_text(encoding="utf-8"),"html.parser")
        prior_version = previous.body.get("data-artifact-version","") if previous.body else ""
        if not STABLE_SEMVER.fullmatch(prior_version) or previous.body.get("data-book") != BOOK_ID or previous.body.get("data-anchor-schema") != "stable-v1":
            parser.error("--previous must be a Pregnancy and Lactation Reader HTML with a stable version and stable-v1 anchors")
        if tuple(map(int,prior_version.split("."))) >= tuple(map(int,version.split("."))):
            parser.error("The successor version must be higher than --previous")
        if prior_version == frozen["version"] and previous_hash != frozen["html_sha256"]:
            parser.error("The predecessor claiming the frozen version has a different hash")

    identities = {name:digest(args.sources/name) for name in (*DOC_NAMES,HTML_NAME)}
    if identities != frozen["sources"]:
        drift = sorted(name for name in identities.keys() | frozen["sources"].keys() if identities.get(name)!=frozen["sources"].get(name))
        parser.error("Locked source identity differs: "+", ".join(drift))
    content,groups,counts,evidence = assemble(args.sources)
    template = TEMPLATE.read_text(encoding="utf-8")
    template = update_reader(template)
    css = Path(__file__).with_name("guide.css").read_text(encoding="utf-8")
    template = template.replace("</head>","<style>"+css+"</style></head>",1)
    template = template.replace("['toggleBengali','details.bengali-fold','Bengali explanations'],","")
    template,n = re.subn(r"(?m)^document\.getElementById\('toggleBengali'\)\.addEventListener[^\n]+\n","",template)
    assert n==1
    replacements = {"TITLE":TITLE,"BOOK_ID":BOOK_ID,"BRAND":"Pregnancy & Lactation","ANCHOR_SCHEMA":"stable-v1","ARTIFACT_VERSION":version,"CONTENT":content}
    output = re.sub(r"\{\{([A-Z_]+)\}\}",lambda m:escape(replacements[m[1]]) if m[1]!="CONTENT" else content,template)
    grades = validate(output,groups,counts,evidence,previous)
    assert all(digest(args.sources/name)==expected for name,expected in identities.items())
    assert args.previous is None or digest(args.previous)==previous_hash
    payload = output.encode("utf-8")
    audit = {"version":version,"html_sha256":sha256(payload).hexdigest(),"previous_sha256":previous_hash,"reader_template_sha256":digest(TEMPLATE),"sources":identities,"rows":dict(counts),"classes":len(groups),"reference_entries":sum(len(s["references"]) for s in evidence[HTML_NAME]["sections"]),"safety_cells":dict(grades)}
    if version == frozen["version"]:
        assert all(audit[key]==frozen[key] for key in ("html_sha256","reader_template_sha256","rows","classes","reference_entries","safety_cells")), "Frozen baseline output differs"
    args.out_dir.mkdir(parents=True,exist_ok=False)
    target = args.out_dir/f"Pregnancy_Lactation_Therapeutic_Classes_{version}.html"
    target.write_bytes(payload)
    (args.out_dir/"build_result.json").write_text(json.dumps(audit,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(audit,indent=2))


if __name__ == "__main__":
    main()
