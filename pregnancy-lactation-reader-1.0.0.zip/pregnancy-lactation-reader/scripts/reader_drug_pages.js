    var drugPages = new Map();
    var drugGroups = new Map();
    var drugIndex = [];

    chapters.forEach(function(ch) {
      var rows = Array.from(ch.el.querySelectorAll('.drug-table tbody tr'));
      if (!rows.length) return;
      var groups = new Map();
      rows.forEach(function(row) {
        var name = row.querySelector('.source-value').textContent.trim();
        var key = name.toLocaleLowerCase('en').replace(/\s+/g, ' ');
        var group = groups.get(key);
        if (!group) {
          group = {name:name, rows:[], chapter:ch};
          groups.set(key, group);
        }
        group.rows.push(row);
        drugGroups.set(row, group);
        drugIndex.push({el:row, text:name, ch:chapters.indexOf(ch), drug:true});
      });
      var toolbar = node('label', 'drug-page-select', 'Drug / product');
      var select = node('select', '');
      select.setAttribute('aria-label','Drug or product in this class');
      var list = Array.from(groups.values());
      list.forEach(function(group, index) {
        var option = node('option', '', group.name);
        option.value = String(index);
        select.appendChild(option);
      });
      select.addEventListener('change', function() {
        navigate(list[Number(select.value)].rows[0], {focus:false});
      });
      toolbar.appendChild(select);
      ch.el.querySelector('.drug-table').before(toolbar);
      drugPages.set(ch, {groups:list, index:0, select:select});
    });

    function isDrugPaged() {
      return prefs.view === 'drug';
    }

    function selectDrugAt(el) {
      if (!isDrugPaged() || !el) return false;
      var group = drugGroups.get(el.closest('.drug-table tbody tr'));
      if (!group) return false;
      var page = drugPages.get(group.chapter);
      var index = page.groups.indexOf(group);
      if (page.index === index) return false;
      page.index = index;
      markPage();
      chromeFor = -1;
      return true;
    }

    function markDrugPages() {
      drugPages.forEach(function(page, ch) {
        var filtered = isDrugPaged() && chapters[active] === ch;
        page.select.value = String(page.index);
        page.groups.forEach(function(group, index) {
          group.rows.forEach(function(row) { row.hidden = filtered && page.index !== index; });
        });
      });
    }

    function drugNeighbor(step) {
      var page = isDrugPaged() && drugPages.get(chapters[active]);
      if (!page) return null;
      var group = page.groups[page.index + step];
      return group ? {title:group.name, el:group.rows[0]} : null;
    }

    function pageStep(step) {
      var neighbor = drugNeighbor(step);
      if (neighbor) {
        navigate(neighbor.el);
        return;
      }
      var next = chapters[active + step];
      var page = isDrugPaged() && next && drugPages.get(next);
      if (page) {
        navigate(page.groups[step > 0 ? 0 : page.groups.length - 1].rows[0]);
        return;
      }
      goChapter(active + step);
    }

    function drugSearch() {
      return prefs.searchMode !== 'all';
    }

    function searchDrugRows(query) {
      var q = query.toLocaleLowerCase('en');
      return drugIndex.filter(function(item) {
        return item.text.toLocaleLowerCase('en').includes(q);
      }).sort(function(a,b) {
        return Number(b.text.toLocaleLowerCase('en') === q) - Number(a.text.toLocaleLowerCase('en') === q);
      });
    }

    function refreshSearchMode() {
      var label = drugSearch() ? 'Search drug names' : 'Search this guide';
      sIn.placeholder = drugSearch() ? 'Enter a drug or product name' : 'Search words or phrases';
      sIn.setAttribute('aria-label', label);
      if (sIn.value) runSearch();
    }

    function openSafetyLegend() {
      var pane = openDialog('Safety color legend');
      var legend = $('guideSafetyLegend').content.cloneNode(true);
      pane.appendChild(legend);
    }
