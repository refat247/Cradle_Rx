import re
from pathlib import Path

from safety_legend import safety_legend


LEGEND_BUTTON = (
    '<button aria-label="Safety color legend" class="reader-icon-btn" id="readerSafetyLegend" '
    'title="Safety color legend" type="button"><svg aria-hidden="true" height="20" viewBox="0 0 20 20" width="20">'
    '<path d="M10 2.5 16 5v4.5c0 3.8-2.8 6.2-6 8-3.2-1.8-6-4.2-6-8V5l6-2.5Zm-2.5 7.8 1.8 1.8 3.4-3.7" '
    'fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>'
    '</svg><span class="reader-btn-text">Safety legend</span></button>'
)
def update_reader(template):
    drug_js = Path(__file__).with_name("reader_drug_pages.js").read_text(encoding="utf-8")
    patches = [
        ('</button></nav></div>\n<div aria-hidden="true" class="reader-progress"',
         '</button>'+LEGEND_BUTTON+'</nav></div>\n<div aria-hidden="true" class="reader-progress"'),
        ('<main class="main-wrap"', safety_legend()+'<main class="main-wrap"'),
        ("button,.chapter-icon,.risk-chip,details", "button,.chapter-icon,.risk-chip,.safety-badge,details"),
        ("if(!p||p.closest('script,style'))continue;", "if(!p||p.closest('script,style,.safety-badge'))continue;"),
        ('    var passages=Array.from(', drug_js+'\n    var passages=Array.from('),
        ("var base=(isPaged()&&chapters[active]&&chapters[active].el)||main;",
         "var base=(chapters[active]&&chapters[active].el)||main;"),
        ("if(el.offsetParent===null||el.closest('details:not([open])'))return;var top=el.getBoundingClientRect().top;if(top<=L",
         "if(!base.contains(el)||el.offsetParent===null||el.closest('details:not([open])'))return;var top=el.getBoundingClientRect().top;if(top<=L"),
        ("if(/^(P|LI|TD|TH|H1|H2|H3|H4|DIV|FIGCAPTION|SMALL)$/.test(el.tagName)",
         "var drugPage=isDrugPaged()&&drugPages.get(chapters[active]);if(drugPage)spot.drug=drugPage.groups[drugPage.index].rows[0].id;\n      if(/^(P|LI|TD|TH|H1|H2|H3|H4|DIV|FIGCAPTION|SMALL)$/.test(el.tagName)"),
        ("if(!el)return {ok:false,mode:'missing'};\n      if(isPaged())", "if(!el)return {ok:false,mode:'missing'};\n      selectDrugAt(spot.drug ? document.getElementById(spot.drug) : el);\n      if(isPaged())"),
        ("      var res=core.restoreTop({rectTop:rectTop", "      if(!isPaged()&&chapters[spot.page]?.el===el)dy=Math.min(dy,0);\n      var res=core.restoreTop({rectTop:rectTop"),
        ("body.classList.toggle('reader-paged',isPaged());markPage();", "body.classList.toggle('reader-paged',isPaged());body.classList.toggle('reader-drug-paged',isDrugPaged());markPage();refreshSearchMode();"),
        ("chapters[active].sec===s);});}", "chapters[active].sec===s);});markDrugPages();}"),
        ("var prev=chapters[active-1],next=chapters[active+1];", "var prev=drugNeighbor(-1)||chapters[active-1],next=drugNeighbor(1)||chapters[active+1];"),
        ("if(!isPaged()&&!navBusy)active=currentIndex();", "if(!isPaged()&&!navBusy){var index=currentIndex();if(index!==active){active=index;markPage();}}"),
        ("if(settingsHolder&&dialog.open&&!settling)settingsHolder.stale=true;", ""),
        ("if(holder&&holder.stale){holder.spot=captureSpot();holder.stale=false;}", ""),
        ("{spot:captureSpot(),stale:false}", "{spot:captureSpot()}"),
        ("select=node('select');values.forEach(function(pair)", "select=node('select');select.setAttribute('aria-label',label);values.forEach(function(pair)"),
        ("cancelMotion();closeDialog();\n      var pi=pageOf(el),switching=false;", "cancelMotion();closeDialog();\n      var pi=pageOf(el),switching=selectDrugAt(el);"),
        ("var pageRoot=isPaged()&&pi>=0&&chapters[pi].el===el;", "var pageRoot=isPaged()&&pi>=0&&(chapters[pi].el===el||(switching&&isDrugPaged()&&drugGroups.has(el)));"),
        ("$('readerPrev').onclick=function(){goChapter(active-1);};$('readerNext').onclick=function(){goChapter(active+1);};",
         "$('readerPrev').onclick=function(){pageStep(-1);};$('readerNext').onclick=function(){pageStep(1);};"),
        ("var all=searchIndex.filter(function(it){return core.findMatches(it.text,q,1).length>0;}),shown=all.slice(0,80);",
         "var byDrug=drugSearch();\n      var all=byDrug?searchDrugRows(q):searchIndex.filter(function(it){return core.findMatches(it.text,q,1).length>0;});\n      var shown=byDrug?all:all.slice(0,80);"),
        ("sStatus.textContent=!all.length?'No matching passages.':all.length+' matching passage'+(all.length===1?'':'s')+(all.length>80?' · showing the first 80':'');",
         "var resultLabel=byDrug?'drug record':'passage';\n      sStatus.textContent=!all.length?'No matching '+resultLabel+'s.':all.length+' matching '+resultLabel+(all.length===1?'':'s')+(!byDrug&&all.length>80?' · showing the first 80':'');"),
        ("var label=core.refLabel(refEntries(it.el),2);if(label)b.appendChild(node('small','sr-meta',label));",
         "var label=it.drug?'Pregnancy · Lactation · '+it.el.querySelector('summary').textContent:core.refLabel(refEntries(it.el),2);\n          if(label)b.appendChild(node('small','sr-meta',label));"),
        ("navigate(it.el,{focus:phone});highlightMatch(it.el,search.query);", "navigate(it.el,{focus:phone});if(!it.drug)highlightMatch(it.el,search.query);"),
        ("[['pages','One topic at a time'],['scroll','Continuous scroll']],prefs.view==='scroll'?'scroll':'pages'",
         "[['pages','One topic at a time'],['drug','One subtopic at a time (one drug)'],['scroll','Continuous scroll']],['drug','scroll'].includes(prefs.view)?prefs.view:'pages'"),
        ("      settingSelect(pane,'Focus reading'", "      settingSelect(pane,'Search scope',[['drug','Drug names only'],['all','All content']],drugSearch()?'drug':'all',function(v){prefs.searchMode=v;});\n      settingSelect(pane,'Focus reading'"),
        ("$('readerSettings').onclick=openSettings;", "$('readerSettings').onclick=openSettings;$('readerSafetyLegend').onclick=openSafetyLegend;"),
        ("j:function(){goChapter(active+1);},n:function(){goChapter(active+1);},']':function(){goChapter(active+1);},k:function(){goChapter(active-1);},p:function(){goChapter(active-1);},'[':function(){goChapter(active-1);}",
         "j:function(){pageStep(1);},n:function(){pageStep(1);},']':function(){pageStep(1);},k:function(){pageStep(-1);},p:function(){pageStep(-1);},'[':function(){pageStep(-1);}"),
    ]
    for old,new in patches:
        assert template.count(old)==1,old
        template = template.replace(old,new,1)
    return template
