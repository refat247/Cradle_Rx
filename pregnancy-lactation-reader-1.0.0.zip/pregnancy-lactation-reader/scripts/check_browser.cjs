const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const { chromium } = require(process.env.GUIDE_PLAYWRIGHT || 'playwright');

const target = path.resolve(process.argv[2]);
const url = pathToFileURL(target).href;
const manifest = process.argv[3] || path.join(path.dirname(target),'build_result.json');
const build = JSON.parse(fs.readFileSync(manifest,'utf8'));
assert.equal(createHash('sha256').update(fs.readFileSync(target)).digest('hex'),build.html_sha256);

async function screenshot(page, name) {
  const folder = process.env.GUIDE_SCREENSHOTS;
  if (!folder) return;
  fs.mkdirSync(folder,{recursive:true});
  await page.screenshot({path:path.join(folder,name)});
}

async function until(page, condition, arg) {
  await page.waitForFunction(condition, arg, { timeout: 8000 });
}

async function setting(page, option, value) {
  await page.locator('#readerSettings').click();
  await page.locator('#readerDialog select').filter({has:page.locator('option[value="'+option+'"]')}).selectOption(value);
  await page.locator('#readerClose').click();
}

async function checkDrugMode(page) {
  await page.goto(url+'#class-beta-blockers');
  await until(page,()=>location.hash==='#class-beta-blockers' && document.querySelector('#class-beta-blockers').classList.contains('is-current'));
  await setting(page,'pages','drug');
  const rows = page.locator('#class-beta-blockers .drug-table tbody tr:visible');
  assert.equal(await rows.count(),1);
  const first = await rows.first().getAttribute('id');
  await page.locator('#readerNext').click();
  assert.equal(await rows.count(),1);
  assert.notEqual(await rows.first().getAttribute('id'),first);
  await page.locator('#readerPrev').click();
  assert.equal(await rows.first().getAttribute('id'),first);
  const select = page.locator('#class-beta-blockers .drug-page-select select');
  const last = (await select.locator('option').count())-1;
  await select.selectOption(String(last));
  assert.equal(await select.inputValue(),String(last));
  const lastRow = await rows.first().getAttribute('id');
  await page.locator('#readerNext').click();
  assert.equal(await rows.count(),0);
  await page.locator('#readerPrev').click();
  assert.equal(await rows.first().getAttribute('id'),lastRow);

  if (!await page.locator('#searchInput').isVisible()) await page.locator('#readerSearch').click();
  await page.locator('#searchInput').fill('propranolo');
  await page.locator('.sr-item').filter({hasText:'Propranolol'}).waitFor();
  await until(page,()=>document.querySelector('#searchStatus').textContent==='1 matching drug record');
  assert.equal(await page.locator('.sr-item').count(),1);
  assert.match(await page.locator('.sr-item').innerText(),/Propranolol.*Pregnancy.*Lactation/s);
  await page.locator('.sr-item').click();
  assert.equal(await rows.first().getAttribute('id'),'docx-drug-135');
  assert.equal(await rows.first().locator('td[data-label="Pregnancy"]').isVisible(),true);
  assert.equal(await rows.first().locator('td[data-label="Lactation"]').isVisible(),true);
  await page.locator('#searchReturn').click();
  assert.equal(await rows.first().getAttribute('id'),lastRow);
  await setting(page,'all','all');
  assert.ok(await page.locator('.sr-item').count()>1);
  await setting(page,'all','drug');
  assert.equal(await page.locator('.sr-item').count(),1);

  await page.goto(url+'#docx-drug-135-cell-3');
  await until(page,()=>document.querySelector('#docx-drug-135').getClientRects().length>0);
  assert.equal(await rows.first().getAttribute('id'),'docx-drug-135');
  assert.equal(await rows.count(),1);
  await setting(page,'pages','scroll');
  assert.ok(await rows.count()>1);
  await until(page,()=>document.querySelector('#class-beta-blockers').classList.contains('is-current'));
  await setting(page,'pages','pages');
  await until(page,()=>document.querySelector('#class-beta-blockers').getClientRects().length>0);
  assert.ok(await rows.count()>1);
  await page.locator('#readerSafetyLegend').click();
  const legend = page.locator('#readerDialog .guide-safety-legend');
  assert.equal(await legend.locator('li').count(),3);
  assert.match(await legend.innerText(),/SAFE.*CAUTION.*AVOID \/ UNSAFE/s);
  const rules = await page.locator('#readerDialog').innerText();
  for (const term of ['First-line','Probably compatible','Class limits','Do not breastfeed','Label advises against','When more than one rule matches','SAFE (ACR) / label advises against']) {
    assert.ok(rules.includes(term),term);
  }
  await page.locator('#readerClose').click();

  await page.goto(url+'#docx-drug-1');
  await until(page,()=>document.querySelector('#docx-drug-1').getClientRects().length>0);
  assert.equal(await page.locator('#docx-drug-1-cell-2').getAttribute('data-safety'),'avoid');
  assert.equal(await page.locator('#docx-drug-1-cell-3').getAttribute('data-safety'),'safe');
  assert.match(await page.locator('#docx-drug-1-cell-2').evaluate(el=>getComputedStyle(el).boxShadow),/inset/);
  const samples = {
    'docx-drug-1-cell-2':'❌ AVOID / UNSAFE',
    'docx-drug-1-cell-3':'✅ SAFE',
    'docx-drug-20-cell-2':'❌ AVOID / UNSAFE',
    'docx-drug-55-cell-2':'⚠️ CAUTION',
    'docx-drug-356-cell-2':'❌ AVOID / UNSAFE',
    'docx-drug-289-cell-3':'❌ AVOID / UNSAFE',
    'oe-01-row-08-cell-2':'✅ SAFE',
    'oe-01-row-24-cell-3':'⚠️ CAUTION',
    'oe-03-row-07-cell-3':'⚠️ CAUTION',
    'oe-05-row-05-cell-2':'⚠️ CAUTION',
    'oe-05-row-28-cell-3':'❌ AVOID / UNSAFE',
    'oe-06-row-08-cell-2':'⚠️ CAUTION',
    'oe-11-row-04-cell-3':'❌ AVOID / UNSAFE',
    'oe-11-row-08-cell-2':'❌ AVOID / UNSAFE',
  };
  for (const [id,label] of Object.entries(samples)) {
    assert.equal(await page.locator('#'+id+' > .safety-badge').textContent(),label,id);
  }
  assert.equal(await page.locator('.drug-table td[data-safety] > .safety-badge').count(),
    1198-build.safety_cells.unmatched);
}

async function clickSource(page, id) {
  const fold = page.locator(id);
  await fold.locator('summary').click();
  assert.equal(await fold.evaluate(el => el.open), true);
  await fold.getByRole('link', {name:'Open source details'}).click();
  await until(page, () => location.hash === '#oe-section-05-references');
  assert.equal(await page.locator('#oe-section-05-references').evaluate(el=>el.open), true);
  const notes = page.locator('#oe-section-05-original-notes');
  assert.equal(await notes.evaluate(el=>el.open), false);
  await notes.locator('summary').click();
  assert.equal(await notes.evaluate(el=>el.open), true);
}

(async () => {
  const browser = await chromium.launch({
    executablePath:process.env.GUIDE_BROWSER_EXECUTABLE,
    headless:true
  });
  const failures = [];
  const requests = [];
  const context = await browser.newContext({viewport:{width:1366,height:900}, offline:true, reducedMotion:'reduce'});
  context.on('request',r=>{if (/^https?:/.test(r.url())) requests.push(r.url());});
  const page = await context.newPage();
  page.on('pageerror',error=>failures.push(error.message));
  await page.goto(url);
  await page.locator('#readerChapter option').last().waitFor({state:'attached'});
  assert.equal(await page.locator('#therapeutic-classes article').count(),build.classes);
  assert.equal(await page.locator('.drug-table tbody tr').count(),599);
  assert.equal(await page.locator('.drug-table tbody tr').filter({hasText:'DOCX 200-249'}).count(),50);
  assert.equal(await page.locator('details[open]').count(),0);
  await page.locator('#toggleReferences').click();
  assert.equal(await page.locator('details.reference-fold:not([open])').count(),0);
  assert.equal(await page.locator('.source-detail-fold[open]').count(),0);
  await page.locator('#toggleReferences').click();
  await page.locator('#readerSearch').click();
  await page.locator('#searchInput').fill('Sertraline');
  const result = page.locator('.sr-item').filter({hasText:/Sertraline/}).first();
  await result.click();
  await until(page,()=>document.querySelector('.reader-found')?.textContent.includes('Sertraline'));
  assert.equal(await page.locator('#searchReturn').isVisible(),true);
  await page.locator('#searchReturn').click();
  assert.equal(await page.locator('#searchReturn').isVisible(),false);
  await page.locator('#searchInput').fill('Acitretin');
  await page.locator('.sr-item').filter({hasText:'DOCX 200-249'}).first().click();
  await until(page,()=>document.querySelector('#docx-drug-200.reader-found')?.textContent.includes('Acitretin'));
  const addedFold = page.locator('#docx-drug-200-source');
  await addedFold.locator('summary').click();
  await addedFold.getByRole('link',{name:'Open source details'}).click();
  await until(page,()=>location.hash==='#word-8');
  assert.match(await page.locator('#word-8').innerText(),/Grading key/);
  await page.locator('#searchReturn').click();
  await page.locator('#sideTabContents').click();
  await page.locator('#tocFilter').fill('CNS: Antidepressants');
  await page.locator('.toc-link').filter({hasText:'CNS: Antidepressants'}).click();
  await until(page,()=>location.hash==='#class-cns-antidepressants');
  await screenshot(page,'desktop.png');
  await clickSource(page,'#oe-05-row-01-source');
  await page.locator('#readerBookmarks').click();
  await page.getByRole('button',{name:'Save current passage'}).click();
  const [download] = await Promise.all([page.waitForEvent('download'),page.getByRole('button',{name:'Export bookmarks'}).click()]);
  const bookmark = await download.path();
  const exported = JSON.parse(fs.readFileSync(bookmark,'utf8'));
  assert.equal(exported.anchor_schema,'stable-v1');
  assert.equal(exported.bookmarks.length,1);
  await page.locator('.reader-bookmark-row button').last().click();
  assert.equal(await page.locator('.reader-bookmark-row').count(),0);
  await page.locator('#readerDialog input[type=file]').setInputFiles({name:'bookmark.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(exported))});
  await page.locator('.reader-bookmark-row button').first().click();
  await until(page,()=>!document.querySelector('#readerDialog').open);
  await checkDrugMode(page);

  const classes = await page.locator('#therapeutic-classes article').evaluateAll(nodes=>nodes.map(n=>n.id));
  const layout = [];
  for (const width of [360,390]) {
    await page.setViewportSize({width,height:850});
    await page.goto(url+'#class-ace-inhibitors-angiotensin-receptor-blockers');
    await until(page,()=>!document.getElementById('class-ace-inhibitors-angiotensin-receptor-blockers').hidden);
    const size = await page.evaluate(()=>({width:innerWidth, client:document.documentElement.clientWidth, scroll:document.documentElement.scrollWidth, cell:getComputedStyle(document.querySelector('#class-ace-inhibitors-angiotensin-receptor-blockers td')).display}));
    assert.equal(size.width,width);
    assert.ok(size.scroll<=size.client);
    assert.equal(size.cell,'block');
    await screenshot(page,'mobile-'+width+'.png');
    layout.push(size);
  }
  for (const theme of ['light','sepia','dark']) {
    await page.locator('#readerSettings').click();
    await page.locator('#readerDialog select').filter({has:page.locator('option[value=sepia]')}).selectOption(theme);
    await page.locator('#readerClose').click();
    assert.equal(await page.locator('body').getAttribute('data-reader-theme'),theme);
    for (const id of classes) {
      await page.evaluate(id=>{location.hash='#'+id;},id);
      await until(page, id=>document.getElementById(id).getClientRects().length>0,id);
      assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=document.documentElement.clientWidth),id);
    }
  }
  await page.goto(url+'#class-antineoplastics');
  await screenshot(page,'mobile-dark.png');
  await setting(page,'pages','drug');
  await page.goto(url+'#docx-drug-135');
  await until(page,()=>document.querySelector('#docx-drug-135').getClientRects().length>0);
  assert.equal(await page.locator('#class-beta-blockers tbody tr:visible').count(),1);
  assert.equal(await page.locator('#docx-drug-135-cell-2 > .safety-badge').isVisible(),true);
  await screenshot(page,'mobile-drug-mode.png');
  await page.locator('#readerSearch').click();
  await page.locator('#searchInput').fill('propranolo');
  await page.locator('.sr-item').filter({hasText:'Propranolol'}).click();
  assert.equal(await page.locator('#docx-drug-135').isVisible(),true);
  assert.equal(await page.locator('#readerSide').isVisible(),false);
  await page.locator('#searchReturn').click();
  await page.locator('#readerSafetyLegend').click();
  assert.equal(await page.locator('#readerDialog').isVisible(),true);
  await screenshot(page,'mobile-legend.png');
  await page.locator('#readerClose').click();
  assert.deepEqual(failures,[]);
  assert.deepEqual(requests,[]);
  console.log(JSON.stringify({passed:true,classes:classes.length,themes:['light','sepia','dark'],layout,requestCount:requests.length,chrome:browser.version()},null,2));
  await browser.close();
})().catch(e=>{console.error(e);process.exit(1);});
