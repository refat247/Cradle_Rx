"""Display classes for the supplied tables. Product combinations stay together."""

WORD_NAMES = {
    "Analgesics, Opioid": "Analgesics, Opioids",
    "Antifungals": "Antifungal Agents",
    "Dermatologicals – Antiacne, Retinoids & Keratolytics": "Dermatology: Retinoids & Keratolytics",
    "Dermatologicals – Emollients, Protectants & Sunscreens": "Dermatology: Emollients, Protectants & Sunscreens",
    "Dermatologicals – Pigmentation, Hair & Other": "Dermatology: Pigmentation, Hair & Other",
    "Dermatologicals – Topical Corticosteroids & Combinations": "Dermatology: Topical Corticosteroids & Combinations",
    "Gastrointestinal – Antacids, Ulcer Healing & PPIs": "Gastrointestinal: Acid Suppressants & Antacids",
    "Gastrointestinal – Antidiarrhoeals & Probiotics": "Gastrointestinal: Antidiarrhoeals & Probiotics",
    "Gastrointestinal – Antiemetics & Vertigo Agents": "Gastrointestinal: Antiemetics & Prokinetics",
}

WORD_ROW_CLASSES = {
    "225": "Intravenous Fluids",
    "226": "Intravenous Fluids",
    "227": "Intravenous Fluids",
    "234": "Gastrointestinal: Antidiarrhoeals & Probiotics",
    "238": "Gastrointestinal: Antiflatulents",
    "243": "Vertigo Agents",
    "244": "Vertigo Agents",
}

# Each span uses the one-based row order inside the corresponding HTML table.
HTML_CLASSES = [
    [
        (1,4,"Penicillins & Beta-lactamase Inhibitors"), (5,6,"Cephalosporins"),
        (7,7,"Carbapenems"), (8,10,"Macrolides"), (11,12,"Tetracyclines"),
        (13,13,"Other Antibacterials"), (14,16,"Aminoglycosides"),
        (17,18,"Glycopeptide Antibacterials"), (19,20,"Quinolones"),
        (21,24,"Other Antibacterials"), (25,30,"Antimycobacterials (TB & Leprosy)"),
    ],
    [(1,10,"Antifungal Agents")],
    [(1,4,"Antivirals"), (5,9,"Anthelmintics & Ectoparasiticides")],
    [
        (1,2,"Calcium Channel Blockers & Combinations"),
        (3,5,"ACE Inhibitors & Angiotensin Receptor Blockers"), (6,7,"Beta-blockers"),
        (8,10,"Diuretics"), (11,11,"Alpha-blockers"), (12,12,"Cardiac Glycosides & Antiarrhythmics"),
        (13,14,"Antianginals"), (15,15,"Lipid-lowering Agents"),
        (16,18,"Antiplatelets, Anticoagulants & Thrombolytics"),
    ],
    [
        (1,11,"CNS: Antidepressants"), (12,13,"CNS: Antipsychotics & Mood Stabilisers"),
        (14,21,"CNS: Anxiolytics, Sedatives & Hypnotics"), (22,28,"CNS: Antiepileptics"),
        (29,29,"CNS: Antimigraine Agents"), (30,30,"CNS: Dementia & Nootropic Agents"),
    ],
    [
        (1,13,"Analgesics & NSAIDs"), (14,18,"Analgesics, Opioids"),
        (19,20,"Muscle Relaxants"), (21,21,"Antigout Agents"),
        (22,22,"Anaesthetics & Neuromuscular Agents"),
    ],
    [
        (1,8,"Dermatology: Acne Agents"), (9,19,"Dermatology: Topical Corticosteroids & Combinations"),
        (20,30,"Dermatology: Other Agents"),
    ],
    [
        (1,9,"Antihistamines & Antiallergics"), (10,10,"Bronchodilators & Anti-asthmatics"),
        (11,11,"Respiratory: Corticosteroids (Inhaled or Intranasal)"),
        (12,12,"Antitussives, Expectorants & Nasal Decongestants"),
    ],
    [
        (1,6,"Gastrointestinal: Acid Suppressants & Antacids"),
        (7,9,"Gastrointestinal: Antiemetics & Prokinetics"), (10,11,"Gastrointestinal: Laxatives & Bowel Agents"),
        (12,14,"Gastrointestinal: Antispasmodics"),
    ],
    [
        (1,4,"Oral Antidiabetics"), (5,5,"Thyroid & Antithyroid Agents"),
        (6,8,"Haematinics (Iron & Anaemia)"), (9,9,"Vitamins"),
        (10,10,"Haemostatics & Antifibrinolytics"), (11,13,"Cardiac Stimulants & Vasopressors"),
        (14,15,"Emergency & Critical Care Agents"), (16,19,"Intravenous Fluids"),
    ],
    [
        (1,3,"Corticosteroids (Systemic)"), (4,4,"Immunosuppressants, DMARDs & Biologics"),
        (5,5,"Antineoplastics"), (6,7,"Ophthalmic Agents"), (8,9,"Urological & Sexual Dysfunction Agents"),
        (10,13,"Vitamins"), (14,15,"Bone, Calcium & Vitamin D Agents"),
        (16,16,"Minerals (Zinc & Magnesium)"), (17,17,"Oral Mucosal Preparations"),
        (18,18,"Antiseptics & Disinfectants"),
    ],
]
