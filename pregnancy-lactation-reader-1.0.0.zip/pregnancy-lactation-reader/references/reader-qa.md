# Reader QA and backlog

## Check the actual staged file

Use the project browser smoke check from the skill root. Run it with an available Node.js and Playwright installation. By default Playwright uses its Chromium installation. To select a local Chromium browser, set `GUIDE_BROWSER_EXECUTABLE`. Set `GUIDE_PLAYWRIGHT` only when Playwright is loaded from a specific installation. Optional `GUIDE_SCREENSHOTS` names a writable scratch directory.

```sh
node scripts/check_browser.cjs "BUILT_HTML" "BUILD_MANIFEST_JSON"
```

The script verifies the HTML hash and checks baseline interactions with network disabled. For an authorized change, update test expectations narrowly and add the changed flow to the smoke check. Inspect screenshots separately when layout changes.

| Area | What to verify |
| --- | --- |
| Preservation | Sources and predecessor still match their original hashes. Compare original clinical cells and relevant notes, A–Z ordering, source counts, grouped rows, section-local references and stable IDs. |
| Search | Drug names only is the default in a fresh profile. A partial `propranolo` returns the Propranolol drug record rather than note mentions. All content restores the broader passage results. Jump to a result and verify Return. Search-generated badges and source text stay distinct. |
| Reading modes | Check One topic, One subtopic and Continuous scroll. In one-drug mode exercise the drug picker, Next/Previous, a class boundary, a deep link and the transition back to another mode. Verify the reading position through changes. |
| Safety display | Check explicit SAFE, CAUTION and AVOID, the three confirmed mixed red examples, and an unmatched cell. Verify Pregnancy and Lactation separately. Inspect the exact label, border, visible source wording and the top-bar rules. |
| Source disclosures | Source link opens the expected section and reference list. Old OpenEvidence notes start closed, including after toggling all references. |
| Bookmarks | Save, export, remove, import and restore. Verify the intended anchor schema and the precise restored position. Cross-copy behavior can depend on local file storage. |
| Mobile and themes | Measure 360 and 390 CSS px. For layout changes add 320 px, enlarged text and landscape checks as applicable. Inspect Light, Sepia and Dark, visible focus, tap targets, table overflow and legend scrolling. Distinguish emulated viewport checks from physical phone tests. |
| Offline and print | Open the exact delivered file through `file://` and verify no HTTP requests during tested offline flows. Test print or actual device behavior when in scope. Record unsupported environments and untested gates explicitly. |

## Roadmap decisions

Treat the earlier UI/UX improvement catalogue as proposed work. Apply only the chosen features. Prefer small successors with clear before/after checks.

| Candidate group | Dependency |
| --- | --- |
| Mobile layout and reachable navigation | Define touch targets, safe areas and no-overlap behavior before a persistent Previous/Next bar. |
| Direct search jumps and Back to drug | Use stable cell and row anchors. Test search Return and source return as separate flows. |
| Neutral label, conditions cue and badge rationale | Use explicit unmatched state first. A condition cue needs verified wording cases. Badge rationale needs recorded rule matches. |
| Aliases, combination search and source comparison | Establish source-backed drug, route and formulation identity before grouping or comparing records. |
| Recent history, private notes and export | Define local privacy controls and export scope first. Preserve source and qualifiers in exported assessment text. |
