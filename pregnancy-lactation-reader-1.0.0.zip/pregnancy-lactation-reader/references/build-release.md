# Build and release

## Locate the project

Find the actual original input directory, current reader HTML and latest review in the user's workspace. Compare the reader's `data-artifact-version` and SHA-256 with its review or build manifest. [baseline.json](baseline.json) describes the frozen reference, which may be older than the user's active reader. Ask for the missing file or identity when a decision depends on it. The package carries a compiler and template. The nine source documents and compiled medical HTML are supplied separately.

Use a local Python 3.10+ environment with [requirements.txt](../scripts/requirements.txt). Run with assertions enabled. Install dependencies in an isolated environment if needed and authorized. Run the commands with the working directory at the skill root. Uppercase names below stand for paths chosen in the current environment.

## Replay and successor

```sh
python scripts/build_guide.py --sources "INPUT_DIR" --out-dir "NEW_REPLAY_DIR"
python scripts/build_guide.py --sources "INPUT_DIR" --previous "PRIOR_HTML" --version X.Y.Z --out-dir "NEW_STAGE_DIR"
```

The default replay verifies the source hashes and requires the output SHA-256 to equal the frozen reader. A successor requires an actual predecessor of the same reader with a lower stable SemVer and a fresh output directory. The compiler checks original row and source wording, locators, references and existing anchors. It emits the standalone HTML and `build_result.json`. Keep the staged HTML immutable after QA. Publish only a hash-matching copy.

The bundled adapter is scoped to the nine known inputs. To add or replace a source, preserve the frozen replay first. Prepare a separately versioned source registry and baseline, update the parser and class map for the new material, and adapt the read-back checks for exactly the authorized change. Check the full retained source set and record any changed anchors with migration evidence. The standard compiler rejects silent hash drift and nonmatching source shapes.

## Use the supplied version-manager

Locate the installed or explicitly supplied `version-manager` and use its actual `scripts/bump_version.py` path. Avoid assuming a Gemini or Codex configuration directory exists on another host.

```sh
python "VERSION_MANAGER/scripts/bump_version.py" "SKILL_ROOT" --inspect
python "VERSION_MANAGER/scripts/bump_version.py" "SKILL_ROOT" --bump patch --message "Describe the skill change" --dry-run
python "VERSION_MANAGER/scripts/bump_version.py" "SKILL_ROOT" --bump patch --message "Describe the skill change"
python "VERSION_MANAGER/scripts/bump_version.py" "SKILL_ROOT" --verify
```

The commands above use a patch as an example. Use **patch** for compatible corrections, **minor** for compatible new capabilities, and **major** for incompatible contract, data schema or anchor changes. Stop a relative bump when declarations drift or none are found. Resolve the version first. Inspect the dry-run and write only the scoped target.

| Version | Current declarations to check |
| --- | --- |
| Skill package | `SKILL.md` metadata, `agents/openai.yaml` top-level version and latest `CHANGELOG.md` release. |
| Reader artifact | CLI version, filename, HTML `data-artifact-version`, manifest and review. Check these explicitly. The supplied tool detects skill declarations and does not replace reader artifact QA. |
| Upstream template | Origin and hash in the project contract and build manifest. Change only with a template upgrade. |

For a reader-only release, keep the installed skill declarations separate. Historical manifest versions and older changelog entries record provenance. For a skill release, validate its structure and links and check its scripts. Package the skill root and exclude temporary output, caches, screenshots, the source documents and the compiled guide. Validate the extracted ZIP again.

## Review outcome

Use [reader-qa.md](reader-qa.md) for the browser checks. Record the exact HTML hash, source accounting, predecessor changes, tests performed and unresolved gates. Report compilation and source preservation separately from clinical review. Keep package creation, installation, fresh-session activation, actual device testing and Git sync separate.
