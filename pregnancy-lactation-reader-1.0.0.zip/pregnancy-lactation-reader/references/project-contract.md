# Project contract

## Frozen reader reference

[baseline.json](baseline.json) records the frozen v1.3.0 HTML, previous v1.2.0 HTML, template and nine source hashes. It records the source-row counts, class count, bibliography count and badge counts. `version` in this manifest describes the frozen reader. Skill SemVer is declared separately in the skill frontmatter, UI metadata and changelog.

- Reader file `Pregnancy_Lactation_Therapeutic_Classes_1.3.0.html`. Its historical review is `Compilation_Review_1.3.0.md`, and `Pregnancy_Lactation_Exact_Status_Wording.md` contains the wording inventory when available in the project outputs. Verify identities rather than assuming a filename proves a version.
- Nine supplied inputs produce 599 rows in 86 therapeutic classes. The eight DOCX files contain 387 rows and cover original numbers 1–395. Four rows group 263–265, 267–269, 270–272 and 273–275. The original HTML supplies 212 unnumbered rows and 415 bibliography entries in 11 original sections. These are source rows. Different formulations, combinations, and records with the same name can overlap.
- The bundled content-free reader comes from the supplied Gemini `source-locked-study-guide` 1.3.0 asset. It uses the CMT V6.1 design base and inherited reader controls. The local compiler adds project-specific behavior. The template and the nine sources have separate hashes.
- The v1.3.0 review covered offline Chrome and measured mobile viewports. Physical phone, print and clinical verification remain open for that review. Recheck the actual artifact for each new release.

## Source and anchor rules

- Keep the nine originals read-only. Validate all input hashes before compiling and again after. Keep the predecessor in place. Treat a new source or a changed hash as a source-change task. Log the old/new files and authorized changes before revising the locked source registry and evidence. Keep the frozen v1.3.0 manifest as historical provenance when preparing a new source set.
- Retain each table cell's content and associations. Preserve separate pregnancy/lactation notes, summaries, old HTML notes, original legends and section-local references. Avoid silently dropping unsupported DOCX structures. Preserve each original number or row locator, including the grouped ranges.
- Classes and names sort case-insensitively A–Z. Preserve multi-ingredient rows and separate records. Matching display names inside one class may share a reader page while their source records stay separate. Drug identity grouping across sources, aliases, brand-to-generic, formulation and route mapping need explicit source evidence.
- Preserve `data-book=pregnancy-lactation-therapeutic-classes` and `stable-v1` anchors on compatible releases. DOCX row IDs use the source number or range. Original HTML IDs use the original section and row order. Append source IDs when possible. Stable IDs support portability through bookmark export/import. Check storage behavior separately for different local paths and browsers.
- OpenEvidence non-table explanations and notes are retained in closed disclosures. References stay closed at initial load. The global reference toggle should avoid opening the old explanation folds.

## Confirmed safety display

The controlling vocabulary and implementation are in [safety_legend.py](../scripts/safety_legend.py). The same vocabulary generates the in-reader legend. Preserve the exact source statement below each badge and test Pregnancy and Lactation independently.

- **✅ SAFE** covers explicit wording such as `Safe`, `Acceptable`, `Compatible`, `First-line` and `Preferred`.
- **⚠️ CAUTION** covers explicit `Caution`, uncertainty such as `Probably compatible` and `Likely safe`, and the approved conditional or evidence-limited wording. A leading `CAUTION` stays yellow when it is followed by a restriction.
- **❌ AVOID / UNSAFE** covers explicit `Avoid`, `Contraindicated`, `Not recommended`, `Do not breastfeed`, `Not indicated`, and `Label advises against`. Keep these confirmed mixed examples red with all qualifiers visible. `Avoid (oral/systemic) · ✅ topical`, `AVOID in 1st trimester; CAUTION after`, and `SAFE (ACR) / label advises against`.
- Narrow wording takes precedence over a matching broad green word. Use the full DOCX rating and the old HTML's opening assessment, with its leading emphasis when present. A later explicit red or caution clause can override a green opening. The rule set also recognizes original leading status symbols. Unmatched wording stays visible without a badge. v1.3.0 has 489 green, 292 yellow, 346 red and 71 unmatched assessment cells.
- Keep the top-bar Safety legend synchronized with vocabulary, precedence and examples. Review negation and ambiguous source statements before approving more terms. Source-only cells, condition cues and new grades need separate decisions when requested.

## File map

| File | Responsibility |
| --- | --- |
| [source_data.py](../scripts/source_data.py) | Read DOCX/HTML and enforce source structure and numbering. |
| [classes.py](../scripts/classes.py) | Assign display classes while preserving original locators. |
| [build_guide.py](../scripts/build_guide.py) | Build the standalone reader, verify read-back and record source hashes. |
| [safety_legend.py](../scripts/safety_legend.py) | Badge vocabulary, precedence and visible rules. |
| [reader_successor.py](../scripts/reader_successor.py), [reader_drug_pages.js](../scripts/reader_drug_pages.js), [guide.css](../scripts/guide.css) | Reader integration, navigation, search and layout. |
| [reader-v6_1.html](../assets/reader-v6_1.html) | Upstream reader shell without the clinical corpus. |
| [check_browser.cjs](../scripts/check_browser.cjs) | Offline Chrome interaction and layout checks for the current contract. |
