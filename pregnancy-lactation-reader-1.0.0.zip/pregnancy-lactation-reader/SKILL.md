---
name: pregnancy-lactation-reader
description: Maintain, rebuild, review, or release the Pregnancy and Lactation Drug Reference offline HTML reader. Use for this project's source compilation, therapeutic class ordering, safety legend, mobile reader, search, bookmarks, and versioned successors. The skill supports study-reader maintenance and source fidelity.
metadata:
  version: 1.0.0
---

# Pregnancy and Lactation Reader

Start with the user's requested scope. Advice, a wording inventory, or a roadmap review is a read-only task. A request to change the reader calls for a new versioned successor. Identify the actual reader and source files before proceeding. The bundled replay reference identifies the frozen v1.3.0 reader and nine source files by hash.

## Project rules

- Preserve the originals and previous HTML versions. Compile only supplied or explicitly selected inputs. Keep assessment wording, qualifiers, source disagreements, references, and local citation numbering intact. Leave the old OpenEvidence explanations closed initially. Add no Bengali or AI explanations.
- Sort therapeutic classes and the drug/product names within them A–Z. Keep grouped products and separate source assessments intact. Keep original item numbers in provenance. Use the counts in the baseline as source-row accounting, with grouped numbers and overlapping products counted as the sources present them.
- Keep the standalone HTML usable offline. Preserve stable row, cell and reference anchors, the bookmark schema, the two search scopes and the three reading views. Audit changes to any of these through their normal entry points.
- Apply safety badges as mappings of source wording, with the original wording visible. Use the confirmed precedence and show the actual rules in the top-bar Safety legend. Record unmapped cells separately. The workflow establishes source fidelity and reader behavior. Clinical evidence review remains a separate task.
- For a version change, use the supplied `version-manager` when available. Inspect first, choose the SemVer scope, preview, synchronize, verify, test and package. Keep the skill's version, the reader's version and upstream template provenance separate.

## Read only the relevant reference

- [Project contract](references/project-contract.md) for source counts, immutable inputs, safety wording, stable IDs and the file map. Use it before content, class or badge edits.
- [Build and release](references/build-release.md) to replay the baseline, build a successor, inspect version drift or package a release.
- [Reader QA and backlog](references/reader-qa.md) for mobile behavior, search, navigation, bookmarks, accessibility and planning dependencies.

Return the requested artifact or findings. When releasing a successor, report its version, verified changes, relevant evidence gaps, and separate package, install, runtime and Git states.
