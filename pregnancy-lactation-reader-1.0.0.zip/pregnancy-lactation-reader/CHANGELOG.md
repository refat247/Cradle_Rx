# Changelog

## [1.0.0] - 2026-11-08

### Added

- Project rules for the Pregnancy and Lactation Drug Reference.
- Portable replay compiler for the frozen reader v1.3.0 and guarded successor builds.
- Browser checks and a release workflow for future source and reader changes.
